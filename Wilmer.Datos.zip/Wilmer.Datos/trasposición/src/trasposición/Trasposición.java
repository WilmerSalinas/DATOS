package trasposición;
import java.util.Random;
import java.util.Scanner;
public class Trasposición {

    public static void main(String[] args) {

        Scanner l = new Scanner(System.in);

        System.out.print("Ingrese el tamaño de la matriz (N): ");
        int N = l.nextInt();

        int[][] matriz = new int[N][N];
        Random random = new Random();

        // Generar la matriz con números aleatorios entre 1 y 99
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                matriz[i][j] = random.nextInt(99) + 1;
            }
        }

        // Mostrar la matriz original
        System.out.println("Matriz Original:");
        mostrarMatriz(matriz);

        // Realizar la transposición sobre la diagonal secundaria
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N - i; j++) {
                int temp = matriz[i][j];
                matriz[i][j] = matriz[N - 1 - j][N - 1 - i];
                matriz[N - 1 - j][N - 1 - i] = temp;
            }
        }

        // Mostrar la matriz transpuesta
        System.out.println("Matriz Resultante:");
        mostrarMatriz(matriz);

    }

    public static void mostrarMatriz(int[][] matriz) {
        int N = matriz.length;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                System.out.printf("%4d", matriz[i][j]);
            }
            System.out.println();
        }
    }
}