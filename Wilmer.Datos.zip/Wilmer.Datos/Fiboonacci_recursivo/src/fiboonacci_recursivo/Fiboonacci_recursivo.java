package fiboonacci_recursivo;
import java.util.Scanner;
public class Fiboonacci_recursivo {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("Ingresa un número para calcular la secuencia de Fibonacci: ");
        int numero = leer.nextInt();
        
        System.out.println("La secuencia de Fibonacci hasta el " + numero + " es:");
        for (int i = 0; i <= numero; i++) {
            System.out.print(fibonacci(i) + " ");
        }
    }
   
    public static int fibonacci(int n) {
        if (n <= 1)
            return n;
        else
            return fibonacci(n - 1) + fibonacci(n - 2);
    }
}