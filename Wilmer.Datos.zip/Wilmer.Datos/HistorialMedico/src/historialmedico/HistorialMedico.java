package historialmedico;
import java.io.*;
import java.util.Scanner;
public class HistorialMedico {
    public static void main(String[] args) {

        Scanner l = new Scanner(System.in);
        String filePath = "HistorialMedico.txt";

        System.out.print("Ingrese la cantidad de pacientes: ");
        int cantidadPacientes = l.nextInt();
        l.nextLine(); // Consumir la nueva línea

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (int i = 0; i < cantidadPacientes; i++) {
                System.out.println("Ingrese los datos del paciente " + (i + 1) + ":");
                
                System.out.print("Cédula de identidad: ");
                String cedula = l.nextLine();   
                
                System.out.print("Apellidos Completos: ");
                String apellidos = l.nextLine();
                
                System.out.print("Nombres completos: ");
                String nombres = l.nextLine();
                
                System.out.print("Fecha de nacimiento: ");
                String fechaNacimiento = l.nextLine();
                
                System.out.print("Estatura: ");
                String estatura = l.nextLine();
                
                System.out.print("Peso: ");
                String peso = l.nextLine();
                
                System.out.print("Alergias: ");
                String alergias = l.nextLine();

                writer.write("Cédula de identidad: " + cedula);
                writer.newLine();
                writer.write("Apellidos Completos: " + apellidos);
                writer.newLine();
                writer.write("Nombres completos: " + nombres);
                writer.newLine();
                writer.write("Fecha de nacimiento: " + fechaNacimiento);
                writer.newLine();
                writer.write("Estatura: " + estatura);
                writer.newLine();
                writer.write("Peso: " + peso);
                writer.newLine();
                writer.write("Alergias: " + alergias);
                writer.newLine();
                writer.write("------------------------------");
                writer.newLine();
            }
            System.out.println("Información de pacientes guardada exitosamente en " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Leer y mostrar la información del archivo
        System.out.println("\nInformación de todos los pacientes:");
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}