package ejemplo.pkg1;

import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Scanner;

public class Ejemplo1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese los datos que desea guardar en el archivo (escriba 'fin' para terminar):");

        try {
            FileWriter archivo = new FileWriter("datos.txt"); // Creamos el archivo de texto
            BufferedWriter escritor = new BufferedWriter(archivo);

            String entrada = "";
            while (!entrada.equalsIgnoreCase("fin")) {
                entrada = scanner.nextLine();
                if (!entrada.equalsIgnoreCase("fin")) {
                    escritor.write(entrada);
                    escritor.newLine(); // Agregamos una nueva línea después de cada entrada
                }
            }

            // Cerramos el flujo de escritura
            escritor.close();
            System.out.println("Los datos se han guardado correctamente en el archivo.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        } finally {
            scanner.close();
        }
        
    }
    
      
}
