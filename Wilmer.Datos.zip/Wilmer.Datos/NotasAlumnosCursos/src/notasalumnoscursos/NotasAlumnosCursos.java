
package notasalumnoscursos;
import java.util.Scanner;
public class NotasAlumnosCursos {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Definir los nombres de los estudiantes y los cursos
        String[] estudiantes = {"Juan", "Lucía", "Vero", "Carlos"};
        String[] cursos = {"Cálculo", "Matemáticas", "Historia", "Ciencias", "Lógica"};

        // Definir la matriz de notas (rellenada con datos de ejemplo)
        int[][] notas = {
            {7, 6, 8, 9, 7},
            {8, 7, 7, 6, 8},
            {7, 8, 8, 9, 8},
            {5, 7, 6, 9, 8}
        };

        // Mostrar la matriz de notas
        System.out.println("Matriz de Notas:");
        mostrarMatriz(notas, estudiantes, cursos);

        // Pedir al usuario que ingrese el nombre del estudiante y del curso
        System.out.print("Ingrese el nombre del estudiante: ");
        String nombreEstudiante = scanner.nextLine();
        System.out.print("Ingrese el nombre del curso: ");
        String nombreCurso = scanner.nextLine();

        // Buscar el índice del estudiante y del curso
        int indiceEstudiante = buscarIndice(estudiantes, nombreEstudiante);
        int indiceCurso = buscarIndice(cursos, nombreCurso);

        // Verificar si se encontraron los índices
        if (indiceEstudiante != -1 && indiceCurso != -1) {
            // Imprimir la nota del estudiante en el curso
            System.out.println(nombreEstudiante + " tiene " + notas[indiceEstudiante][indiceCurso] + " en " + nombreCurso);
        } else {
            System.out.println("Estudiante o curso no encontrado.");
        }

        scanner.close();
    }

    public static void mostrarMatriz(int[][] matriz, String[] estudiantes, String[] cursos) {
        System.out.print("         ");
        for (String curso : cursos) {
            System.out.print(curso + " ");
        }
        System.out.println();
        for (int i = 0; i < matriz.length; i++) {
            System.out.print(estudiantes[i] + " ");
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("  " + matriz[i][j] + "      ");
            }
            System.out.println();
        }
    }

    public static int buscarIndice(String[] array, String valor) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].equalsIgnoreCase(valor)) {
                return i;
            }
        }
        return -1; // Retorna -1 si no se encuentra el valor
    }
}
