package gestionasientos;
import java.util.Scanner;

public class GestionAsientos {

    public static void main(String[] args) {
        Scanner l = new Scanner(System.in);

        // Definir el tamaño del avión
        int N = 5; // Número de filas
        int M = 4; // Número de asientos por fila

        // Crear la matriz de asientos (true = ocupado, false = vacío)
        boolean[][] asientos = new boolean[N][M];

        while (true) {
            System.out.println("\nMenú:");
            System.out.println("1. Ver estado de los asientos");
            System.out.println("2. Escoger un asiento");
            System.out.println("3. Liberar un asiento");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = l.nextInt();

            switch (opcion) {
                case 1:
                    mostrarAsientos(asientos);
                    break;
                case 2:
                    escogerAsiento(asientos, l);
                    break;
                case 3:
                    liberarAsiento(asientos, l);
                    break;
                case 4:
                    System.out.println("Saliendo del sistema.");
                    l.close();
                    return;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        }
    }

    public static void mostrarAsientos(boolean[][] asientos) {
        System.out.println("Estado actual de los asientos (O = Ocupado, V = Vacío):");
        for (int i = 0; i < asientos.length; i++) {
            for (int j = 0; j < asientos[i].length; j++) {
                System.out.print(asientos[i][j] ? "O " : "V ");
            }
            System.out.println();
        }
    }

    public static void escogerAsiento(boolean[][] asientos, Scanner scanner) {
        System.out.print("Ingrese el número de fila (1-" + asientos.length + "): ");
        int fila = scanner.nextInt() - 1;
        System.out.print("Ingrese el número de asiento (1-" + asientos[0].length + "): ");
        int asiento = scanner.nextInt() - 1;

        if (fila >= 0 && fila < asientos.length && asiento >= 0 && asiento < asientos[0].length) {
            if (!asientos[fila][asiento]) {
                asientos[fila][asiento] = true;
                System.out.println("Asiento ocupado exitosamente.");
            } else {
                System.out.println("El asiento ya está ocupado.");
            }
        } else {
            System.out.println("Número de fila o asiento inválido.");
        }
    }

    public static void liberarAsiento(boolean[][] asientos, Scanner scanner) {
        System.out.print("Ingrese el número de fila (1-" + asientos.length + "): ");
        int fila = scanner.nextInt() - 1;
        System.out.print("Ingrese el número de asiento (1-" + asientos[0].length + "): ");
        int asiento = scanner.nextInt() - 1;

        if (fila >= 0 && fila < asientos.length && asiento >= 0 && asiento < asientos[0].length) {
            if (asientos[fila][asiento]) {
                asientos[fila][asiento] = false;
                System.out.println("Asiento liberado exitosamente.");
            } else {
                System.out.println("El asiento ya está vacío.");
            }
        } else {
            System.out.println("Número de fila o asiento inválido.");
        }
    }
}
