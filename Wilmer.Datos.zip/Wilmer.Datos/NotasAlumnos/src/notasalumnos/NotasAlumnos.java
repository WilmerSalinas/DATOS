package notasalumnos;
public class NotasAlumnos {

    public static void main(String[] args) {
        // Definición del tamaño de la matriz
        int filas = 4; // Número de alumnos
        int columnas = 5; // Número de cursos

        // Inicialización de la matriz con las notas predefinidas
        int[][] notas = {
            {7, 6, 8, 9, 7},
            {8, 7, 7, 6, 8},
            {7, 8, 8, 9, 8},
            {5, 7, 6, 9, 8}
        };

        // Mostrar la matriz de notas
        System.out.println("Matriz de Notas:");
        mostrarMatriz(notas);
    }

    public static void mostrarMatriz(int[][] matriz) {
        int filas = matriz.length;
        int columnas = matriz[0].length;
        System.out.print("     "); // Espacio inicial para la cabecera
        for (int j = 0; j < columnas; j++) {
            System.out.print("Curso" + j + " ");
        }
        System.out.println();
        for (int i = 0; i < filas; i++) {
            System.out.print("Alumno" + i + " ");
            for (int j = 0; j < columnas; j++) {
                System.out.print(matriz[i][j] + "     ");
            }
            System.out.println();
        }
    }
}
