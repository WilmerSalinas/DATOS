package registrocivil;
import java.util.Scanner;

public class RegistroCivil {
    public static void main(String[] args) {
        Scanner l = new Scanner(System.in);

        System.out.print("Ingrese el tamaño del arreglo (N): ");
        int N = l.nextInt();
        l.nextLine();  // Consumir la línea nueva

        String[] clientes = new String[N];
        int numClientes = 0;

        while (true) {
            System.out.println("\nMenú:");
            System.out.println("1. Ingresar nuevo cliente");
            System.out.println("2. Atender cliente");
            System.out.println("3. Cliente se retira");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = l.nextInt();
            l.nextLine();  // Consumir la línea nueva

            switch (opcion) {
                case 1:
                    if (numClientes < N) {
                        System.out.print("Ingrese la cédula del nuevo cliente: ");
                        String cedula = l.nextLine();
                        clientes[numClientes] = cedula;
                        numClientes++;
                        System.out.println("Cliente ingresado exitosamente.");
                    } else {
                        System.out.println("No se pueden ingresar más clientes. El arreglo está lleno.");
                    }
                    break;
                case 2:
                    if (numClientes > 0) {
                        System.out.println("Atendiendo al cliente con cédula: " + clientes[0]);
                        // Mover todos los clientes a la izquierda
                        for (int i = 0; i < numClientes - 1; i++) {
                            clientes[i] = clientes[i + 1];
                        }
                        clientes[numClientes - 1] = null;
                        numClientes--;
                    } else {
                        System.out.println("No hay clientes para atender.");
                    }
                    break;
                case 3:
                    if (numClientes > 0) {
                        System.out.print("Ingrese la cédula del cliente que se retira: ");
                        String cedulaRetiro = l.nextLine();
                        int index = -1;
                        for (int i = 0; i < numClientes; i++) {
                            if (clientes[i].equals(cedulaRetiro)) {
                                index = i;
                                break;
                            }
                        }
                        if (index != -1) {
                            // Mover todos los clientes a la izquierda desde el índice encontrado
                            for (int i = index; i < numClientes - 1; i++) {
                                clientes[i] = clientes[i + 1];
                            }
                            clientes[numClientes - 1] = null;
                            numClientes--;
                            System.out.println("El cliente se ha retirado exitosamente.");
                        } else {
                            System.out.println("Cliente no encontrado.");
                        }
                    } else {
                        System.out.println("No hay clientes en la cola.");
                    }
                    break;
                case 4:
                    System.out.println("Saliendo del sistema.");
                    l.close();
                    return;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }

            // Mostrar el estado actual del arreglo
            System.out.print("Clientes en la cola: ");
            for (int i = 0; i < numClientes; i++) {
                System.out.print(clientes[i] + " ");
            }
            System.out.println();
        }
    }
}