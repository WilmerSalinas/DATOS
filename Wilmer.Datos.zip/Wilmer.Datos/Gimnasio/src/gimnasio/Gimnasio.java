package gimnasio;
import java.util.Scanner;
public class Gimnasio {
    public static void main(String[] args) {

        Scanner l = new Scanner(System.in);

        // Arreglo con los nombres de los clientes inscritos
        String[] clientes = {"Juan", "María", "Pedro", "Lucía", "Carlos", "Ana", "Luis", "Sofía", "Jorge", "Marta"};

        // Matriz para registrar la asistencia (6 días de la semana)
        boolean[][] asistencia = new boolean[clientes.length][6];

        // Registro de asistencia
        System.out.println("Ingrese la asistencia de los clientes (1 para presente, 0 para ausente):");
        for (int i = 0; i < clientes.length; i++) {
            System.out.println("Asistencia de " + clientes[i] + ":");
            for (int j = 0; j < 6; j++) {
                System.out.print("Día " + (j + 1) + ": ");
                int presencia = l.nextInt();
                asistencia[i][j] = presencia == 1;
            }
        }

        // Determinar los clientes con al menos tres asistencias
        System.out.println("\nClientes con al menos tres asistencias y 20% de descuento:");
        for (int i = 0; i < clientes.length; i++) {
            int conteoAsistencia = 0;
            for (int j = 0; j < 6; j++) {
                if (asistencia[i][j]) {
                    conteoAsistencia++;
                }
            }
            if (conteoAsistencia >= 3) {
                System.out.println(clientes[i]);
            }
        }
    }
}
