package calculonotas;
import java.util.Random;
public class CalculoNotas {
    public static void main(String[] args) {

        final int NUM_ESTUDIANTES = 20;
        final int NUM_ASIGNATURAS = 4;
        
        // Crear una matriz para almacenar las notas de los estudiantes
        double[][] notas = new double[NUM_ESTUDIANTES][NUM_ASIGNATURAS];
        
        // Generar notas aleatorias entre 0 y 10
        Random rand = new Random();
        for (int i = 0; i < NUM_ESTUDIANTES; i++) {
            for (int j = 0; j < NUM_ASIGNATURAS; j++) {
                notas[i][j] = rand.nextInt(11); // Genera un número entre 0 y 10 inclusive
            }
        }
        
        // Calcular y mostrar la media de cada alumno
        System.out.println("Media de cada alumno:");
        for (int i = 0; i < NUM_ESTUDIANTES; i++) {
            double sumaNotasAlumno = 0;
            for (int j = 0; j < NUM_ASIGNATURAS; j++) {
                sumaNotasAlumno += notas[i][j];
            }
            double mediaAlumno = sumaNotasAlumno / NUM_ASIGNATURAS;
            System.out.printf("Alumno %d: %.2f%n", i + 1, mediaAlumno);
        }
        
        // Calcular y mostrar la media de cada asignatura
        System.out.println("\nMedia de cada asignatura:");
        for (int j = 0; j < NUM_ASIGNATURAS; j++) {
            double sumaNotasAsignatura = 0;
            for (int i = 0; i < NUM_ESTUDIANTES; i++) {
                sumaNotasAsignatura += notas[i][j];
            }
            double mediaAsignatura = sumaNotasAsignatura / NUM_ESTUDIANTES;
            System.out.printf("Asignatura %d: %.2f%n", j + 1, mediaAsignatura);
        }
        
        // Calcular y mostrar la media de toda la clase
        double sumaTotalNotas = 0;
        for (int i = 0; i < NUM_ESTUDIANTES; i++) {
            for (int j = 0; j < NUM_ASIGNATURAS; j++) {
                sumaTotalNotas += notas[i][j];
            }
        }
        double mediaClase = sumaTotalNotas / (NUM_ESTUDIANTES * NUM_ASIGNATURAS);
        System.out.printf("%nMedia de toda la clase: %.2f%n", mediaClase);
    }
}