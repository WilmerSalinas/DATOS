package factorial;
import java.util.Scanner;
public class Factorial {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        
        int n = 0 ;
        factorial(n);
        System.out.println("Fin");
    
        System.out.println(" Ingrese el numero a calcular");
        n = leer.nextInt();    
        System.out.println(factorial (n) );
        System.out.println("fin");
        
       }
    static long factorial(int n ){
        if (n == 0 ){
        return 1;
    }else if( n < 0 ){
        System.out.println("El numero ingresado es menor a 0");
        }else{
        return n * factorial (n-1);
        }
    return 0;
    
    } 
    
}
